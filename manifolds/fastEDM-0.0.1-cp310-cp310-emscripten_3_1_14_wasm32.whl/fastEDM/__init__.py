import _fastEDM
from .edm import edm, create_manifold
from .easy_edm import easy_edm

from _fastEDM import run_command
from .edm import edm, create_manifold
